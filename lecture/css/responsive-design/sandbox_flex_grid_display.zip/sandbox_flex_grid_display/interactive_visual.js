const appState = {
  mode: 'flex',
  gap: 10,
  flexDirection: 'row',
  flexJustify: 'center',
  flexAlign: 'center',
  flexWrap: 'nowrap',
  gridCols: 'repeat(3, 1fr)',
  gridAlign: 'center',
  gridJustify: 'stretch',
  itemDisplay: 'block',
  itemWidth: 120,
  itemHeight: 72,
  targetBox: 1
};

const appElements = {
  sandbox: document.getElementById('sandbox'),
  flexControls: document.getElementById('flex-controls'),
  gridControls: document.getElementById('grid-controls'),
  displayControls: document.getElementById('display-controls'),
  gapControl: document.getElementById('gap-control'),
  codeSnippet: document.getElementById('code-snippet'),
  gapSlider: document.getElementById('gap-slider'),
  gapVal: document.getElementById('gap-slider-val'),
  displayWidthSlider: document.getElementById('display-width-slider'),
  displayWidthVal: document.getElementById('display-width-val'),
  displayHeightSlider: document.getElementById('display-height-slider'),
  displayHeightVal: document.getElementById('display-height-val'),
  displayTargetSlider: document.getElementById('display-target-slider'),
  displayTargetVal: document.getElementById('display-target-val')
};

function getCurrentCssRules() {
  if (appState.mode === 'flex') {
    return {
      display: 'flex',
      'flex-direction': appState.flexDirection,
      'justify-content': appState.flexJustify,
      'align-items': appState.flexAlign,
      'flex-wrap': appState.flexWrap,
      gap: `${appState.gap}px`
    };
  }

  if (appState.mode === 'display') {
    return { display: 'block' };
  }

  return {
    display: 'grid',
    'grid-template-columns': appState.gridCols,
    'align-items': appState.gridAlign,
    'justify-items': appState.gridJustify,
    gap: `${appState.gap}px`
  };
}

function renderCodeSnippet() {
  const { codeSnippet } = appElements;
  if (!codeSnippet) return;

  const cssRules = getCurrentCssRules();
  if (appState.mode === 'display') {
    codeSnippet.innerHTML = '<span class="code-keyword">.container</span> {\n' +
      '  <span class="code-prop">display</span>: <span class="code-val">block</span>;\n' +
      '}\n\n' +
      '<span class="code-keyword">.item</span> {\n' +
      `  <span class="code-prop">display</span>: <span class="code-val">${appState.itemDisplay}</span>;\n` +
      '}\n\n' +
      `<span class="code-keyword">.box-item-${appState.targetBox}</span> {\n` +
      `  <span class="code-prop">width</span>: <span class="code-val">${appState.itemWidth}px</span>;\n` +
      `  <span class="code-prop">height</span>: <span class="code-val">${appState.itemHeight}px</span>;\n` +
      '}';
    return;
  }

  let html = '<span class="code-keyword">.container</span> {\n';

  Object.entries(cssRules).forEach(([property, value]) => {
    html += `  <span class="code-prop">${property}</span>: <span class="code-val">${value}</span>;\n`;
  });

  html += '}';
  codeSnippet.innerHTML = html;
}

function applySandboxStyles() {
  const { sandbox } = appElements;
  if (!sandbox) return;

  sandbox.style.cssText = '';
  const cssRules = getCurrentCssRules();
  Object.entries(cssRules).forEach(([property, value]) => {
    sandbox.style.setProperty(property, value);
  });

  sandbox.querySelectorAll('.box-item').forEach((item) => {
    item.style.display = appState.mode === 'display' ? appState.itemDisplay : '';
    const isTargetBox = appState.mode === 'display' &&
      item.classList.contains(`box-item-${appState.targetBox}`);
    item.style.width = isTargetBox ? `${appState.itemWidth}px` : '';
    item.style.height = isTargetBox ? `${appState.itemHeight}px` : '';
  });
}

function updateViz() {
  try {
    const { flexControls, gridControls, displayControls, gapControl } = appElements;

    if (flexControls) flexControls.style.display = appState.mode === 'flex' ? 'grid' : 'none';
    if (gridControls) gridControls.style.display = appState.mode === 'grid' ? 'grid' : 'none';
    if (displayControls) displayControls.style.display = appState.mode === 'display' ? 'grid' : 'none';
    if (gapControl) gapControl.style.display = appState.mode === 'display' ? 'none' : '';

    applySandboxStyles();
    renderCodeSnippet();
  } catch (error) {
    console.error('Render error:', error);
  }
}

function updateGapDisplay() {
  const { gapSlider, gapVal } = appElements;
  if (!gapSlider || !gapVal) return;

  const percent = ((Number(gapSlider.value) - Number(gapSlider.min)) / (Number(gapSlider.max) - Number(gapSlider.min))) * 100;
  gapSlider.style.setProperty('--progress', `${percent}%`);
  gapVal.textContent = `${gapSlider.value}px`;
}

function updateDisplayDimension(slider, valueElement) {
  if (!slider || !valueElement) return;

  const percent = ((Number(slider.value) - Number(slider.min)) /
    (Number(slider.max) - Number(slider.min))) * 100;
  slider.style.setProperty('--progress', `${percent}%`);
  valueElement.textContent = `${slider.value}px`;
}

function updateDisplayTarget() {
  const { displayTargetSlider, displayTargetVal } = appElements;
  if (!displayTargetSlider || !displayTargetVal) return;

  const percent = ((Number(displayTargetSlider.value) - Number(displayTargetSlider.min)) /
    (Number(displayTargetSlider.max) - Number(displayTargetSlider.min))) * 100;
  displayTargetSlider.style.setProperty('--progress', `${percent}%`);
  displayTargetVal.textContent = `Box ${displayTargetSlider.value}`;
}

function setMode(mode) {
  appState.mode = mode;

  if (mode === 'grid' && appState.gap === 10) {
    appState.gap = 15;
    if (appElements.gapSlider) appElements.gapSlider.value = '15';
  } else if (mode === 'flex' && appState.gap === 15) {
    appState.gap = 10;
    if (appElements.gapSlider) appElements.gapSlider.value = '10';
  }

  updateGapDisplay();
  updateViz();
}

function bindModeToggle() {
  const modeButtons = document.querySelectorAll('#mode-toggle .lumi-segmented-btn');
  modeButtons.forEach((button) => {
    button.addEventListener('click', (event) => {
      modeButtons.forEach((item) => item.classList.remove('is-selected'));
      event.currentTarget.classList.add('is-selected');
      setMode(event.currentTarget.dataset.mode);
    });
  });
}

function bindSelects() {
  document.querySelectorAll('.lumi-select').forEach((select) => {
    select.addEventListener('change', (event) => {
      const { key } = event.target.dataset;
      if (!key) return;
      appState[key] = event.target.value;
      updateViz();
    });
  });
}

function bindGapSlider() {
  const { gapSlider } = appElements;
  if (!gapSlider) return;

  gapSlider.addEventListener('input', (event) => {
    appState.gap = Number(event.target.value);
    updateGapDisplay();
    updateViz();
  });
}

function bindDisplayDimensionSlider(slider, stateKey, valueElement) {
  if (!slider) return;

  slider.addEventListener('input', (event) => {
    appState[stateKey] = Number(event.target.value);
    updateDisplayDimension(slider, valueElement);
    updateViz();
  });
}

function bindDisplayTargetSlider() {
  const { displayTargetSlider } = appElements;
  if (!displayTargetSlider) return;

  displayTargetSlider.addEventListener('input', (event) => {
    appState.targetBox = Number(event.target.value);
    updateDisplayTarget();
    updateViz();
  });
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  updateViz();
}

function setupThemeSync() {
  const mediaQuery = window.matchMedia?.('(prefers-color-scheme: dark)');
  if (!mediaQuery) return;

  const currentTheme = document.documentElement.getAttribute('data-theme');
  if (!currentTheme) {
    applyTheme(mediaQuery.matches ? 'dark' : 'light');
  }

  mediaQuery.addEventListener?.('change', (event) => {
    if (!document.documentElement.hasAttribute('data-theme')) {
      applyTheme(event.matches ? 'dark' : 'light');
    }
  });

  window.addEventListener('message', (event) => {
    const payload = event.data;
    if (payload && (payload.type === 'set-theme' || payload.type === 'APPLY_THEME') && payload.theme) {
      applyTheme(payload.theme);
    }
  });
}

function notifyHeight() {
  const container = document.querySelector('.widget-container') || document.body;
  if (!container) return;

  const height = Math.ceil(Math.max(container.getBoundingClientRect().bottom, container.scrollHeight));
  window.parent.postMessage({ type: 'widget-resize', height }, '*');
}

function setupAutoResize() {
  window.addEventListener('load', () => setTimeout(notifyHeight, 120));
  const target = document.querySelector('.widget-container') || document.body;
  if (target && 'ResizeObserver' in window) {
    new ResizeObserver(() => notifyHeight()).observe(target);
  }
}

function initApp() {
  bindModeToggle();
  bindSelects();
  bindGapSlider();
  bindDisplayDimensionSlider(appElements.displayWidthSlider, 'itemWidth', appElements.displayWidthVal);
  bindDisplayDimensionSlider(appElements.displayHeightSlider, 'itemHeight', appElements.displayHeightVal);
  bindDisplayTargetSlider();
  updateGapDisplay();
  updateDisplayDimension(appElements.displayWidthSlider, appElements.displayWidthVal);
  updateDisplayDimension(appElements.displayHeightSlider, appElements.displayHeightVal);
  updateDisplayTarget();
  updateViz();
  setupThemeSync();
  setupAutoResize();
}

document.addEventListener('DOMContentLoaded', initApp);

/*luminous-slider-normalizer*/(function(){function f(r){if(!r||r.type!=='range')return;var mn=parseFloat(r.min||'0'),mx=parseFloat(r.max||'100'),v=parseFloat(r.value);if(isNaN(v))v=(mn+mx)/2;var p=mx>mn?((v-mn)/(mx-mn))*100:50;r.style.setProperty('--progress',p+'%');r.style.removeProperty('--slider-fill');}function all(){document.querySelectorAll('input[type="range"], .lumi-slider').forEach(f);}document.addEventListener('input',function(e){f(e.target);});if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',all);else all();})();
