(function() {
  function syncBody() {
    var dt = document.documentElement.getAttribute('data-theme');
    if (document.body && (dt === 'dark' || dt === 'light')) {
      document.body.classList.toggle('dark-mode', dt === 'dark');
    }
  }
  function syncTheme(theme) {
    if (theme !== 'dark' && theme !== 'light') return;
    document.documentElement.setAttribute('data-theme', theme);
    syncBody();
  }
  if (typeof MutationObserver === 'function') {
    new MutationObserver(syncBody).observe(document.documentElement, {
      attributes: true, attributeFilter: ['data-theme']
    });
  }
  if (typeof document.addEventListener === 'function') {
    document.addEventListener('DOMContentLoaded', syncBody);
  }
  try {
    var mq = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)');
    if (mq) {
      var cur = document.documentElement.getAttribute('data-theme');
      if (!cur) {
        syncTheme(mq.matches ? 'dark' : 'light');
      } else {
        syncTheme(cur);
      }
      if (mq.addEventListener) {
        mq.addEventListener('change', function(e) {
          syncTheme(e.matches ? 'dark' : 'light');
        });
      }
    }
  } catch (e) {}
  window.addEventListener('message', function(e) {
    if (e.data && (e.data.type === 'set-theme' || e.data.type === 'APPLY_THEME') && e.data.theme) {
      syncTheme(e.data.theme);
    }
  });
})();
